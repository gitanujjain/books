# CDC-Debezium
Change Data Capture with debezium mongo connector

## Reference
[Hands on: CDC Debezium + Kafka Connect + MongoDB](https://medium.com/@mengineer/hands-on-cdc-debezium-kafka-connect-mongodb-4960d5698c67)

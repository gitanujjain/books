# Python Module example

def fun():
    print("something here inside fun()")









a = 0
b = "empty"

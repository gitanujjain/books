# Python Module example

#function definition
def equal(a, b):
    if(a == b):
        return True









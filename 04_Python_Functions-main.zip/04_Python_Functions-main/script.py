import sys
#print(sys.argv[0], argv[1],sys.argv[2])  # this line would print out: filename argument1 argument2
print('Welcome {}. Enjoy  {} for Data Science ^_^'.format(sys.argv[1], sys.argv[2]))





print("Welcome to Dr Parmar's Python4DataScience class")

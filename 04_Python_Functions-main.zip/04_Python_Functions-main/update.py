import config

config.a = 10          # updating value of a to 10
config.b = "alphabet"  # updating value of b to "alphabet"
# Hands-on-PySpark-Kafka-Streaming-OpenAI
 

## Reference
[Hands-on: pyspark+kafka streaming+openai](https://medium.com/@mengineer/hands-on-pyspark-kafka-streaming-openai-a4dc2947216c)
